using System;

namespace Wrox.ProCSharp.Basics
{

	public enum TimeOfDay
	{
	   Morning = 0,
	   Afternoon = 1,
	   Evening = 2
	}

   class EnumExample
	{
	   public static int Main()
	   {
	      WriteGreeting(TimeOfDay.Morning);
	      return 0;
	   }

	   static void WriteGreeting(TimeOfDay timeOfDay)
	   {
	      switch(timeOfDay)
	      {
	         case TimeOfDay.Morning:
	            Console.WriteLine("Good morning!");
	            break;
	         case TimeOfDay.Afternoon:
	            Console.WriteLine("Good afternoon!");
	            break;
	         case TimeOfDay.Evening:
	            Console.WriteLine("Good evening!");
	            break;
	         default:
	            Console.WriteLine("Hello!");
	            break;
	      }
	   }
	}
}
